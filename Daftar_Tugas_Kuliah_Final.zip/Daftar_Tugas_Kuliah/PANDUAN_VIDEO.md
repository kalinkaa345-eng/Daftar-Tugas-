# Panduan Video Penjelasan

1. Perkenalkan program Daftar Tugas Kuliah dan tujuannya.
2. Tunjukkan `main.py` dan package `tugas_kuliah`, lalu jelaskan tugas setiap modul.
3. Jalankan program. Buat file, masukkan tugas dengan status `Belum selesai`, masukkan satu tugas dengan status `Selesai`, lalu tampilkan daftar dan buat laporan.
4. Jelaskan `*args`, `**kwargs`, lambda untuk pengurutan, serta keyword argument pada pemanggilan fungsi.
5. Jelaskan mode file `x`, `a`, `r`, dan `w`, berikut penanganan file yang belum ada dan baris yang rusak.
6. Tunjukkan enam pengujian `unittest` dan tabel refactoring. Sebutkan rename variable, extract function, dan remove duplicate code.
7. Tutup dengan ringkasan bahwa contoh sebelum dan sesudah refactoring menghasilkan keluaran yang sama.

Jalankan program dengan `python main.py`. Jalankan tes dengan `python -m unittest tugas_kuliah.testing`. Gunakan data contoh saat merekam.
