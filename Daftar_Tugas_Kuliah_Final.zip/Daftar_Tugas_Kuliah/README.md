# Daftar Tugas Kuliah

Program ini menyimpan tugas kuliah ke file teks, menampilkan daftar tugas dan status, menghitung tugas yang belum selesai, serta membuat laporan.

## Struktur folder

- `main.py`: menu program.
- `tugas_kuliah/`: package dengan `__init__.py` dan lima modul.
- `tugas_kuliah/aplikasi.py`: class pengelola daftar tugas.
- `tugas_kuliah/processing.py`: class satu tugas, pembentukan record, dan analisis.
- `tugas_kuliah/fileio.py`: operasi file.
- `tugas_kuliah/validasi.py`: validasi input.
- `tugas_kuliah/testing.py`: enam pengujian `unittest`.
- `sebelum_refactoring/` dan `sesudah_refactoring/`: contoh refactoring dengan keluaran yang sama.
- `REFACTORING.md`: tabel perbandingan teknik refactoring.
- `PANDUAN_VIDEO.md`: urutan penjelasan video.

## Menjalankan program

Jalankan `python main.py` dari folder utama. Pilih menu 1 untuk membuat `data_tugas.txt`, lalu menu 2 untuk menambah tugas. Status harus diisi `Belum selesai` atau `Selesai`. Kolom catatan boleh dikosongkan.

Untuk menjalankan pengujian, gunakan `python -m unittest tugas_kuliah.testing`.
